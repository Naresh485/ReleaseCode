﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using System.Net.Mail;

namespace OrcBotPswdUpdate
{
    class Program
    {
        static ChromeDriver chrome;
        //static IWebDriver driver;
        static bool login;
        static string sdr1, sdr2, sdr3;

        //NLog recommends using a static variable for the logger object
        //private static Logger logger = LogManager.GetCurrentClassLogger();

        static LogWriter log = new LogWriter("Log Started");
        static void Main(string[] args)
        {
            //logger.Info("Started Execution.");
            log.LogWrite("Started Execution.");
            
            getPwd();

            try
            {
                string[] botNames = { "RX732RO", "RX922RO", "RX922PPRo" };

                foreach (string bot in botNames)
                {
                    string pwd = string.Empty;

                    if (bot == "RX732RO")
                        pwd = sdr1;
                    else if (bot == "RX922RO")
                        pwd = sdr2;
                    else if (bot == "RX922PPRo")
                        pwd = sdr3;

                    Login();

                    if (login == true)
                    {
                        chrome.Navigate().GoToUrl("https://azased0013.nestle.com/?tid=1&fid=3");
                        chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

                        Thread.Sleep(30);
                        changeMultipleBotPassword(bot, pwd);

                        Logout();

                    }
                    else
                    {
                        chrome.Close();
                        chrome.Quit();
                    }

                    log.LogWrite("End of the Execution.");

                    chrome.Quit();
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("The underlying connection was closed"))
                {
                    log.LogWrite("TPAM Services are unavailable. Error Message: " + ex.Message);

                    log.LogWrite("Mail sending starts.");

                    string sBody = "Dear Kausar,\n\nThe TPAM Services are currently not available. Error Message:" + ex.Message + ". \n\nRegards\n" + "Kausar";
                    MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                    SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                    client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                    try
                    {
                        client.Send(message);
                        log.LogWrite("Mail is sent.");

                    }
                    catch (Exception ex1)
                    {
                        Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                    ex1.ToString());
                        log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                    }

                }
                else
                {
                    log.LogWrite(ex.Message);
                }
                //throw;
            }


            #region
            //    try
            //    {
            //        //logger.Debug("Started the TPAM Services.");
            //        log.LogWrite("Started the TPAM Services.");

            //        //Old link
            //        //TPAMWebServices.iWSRoboticsClient tpams = new TPAMWebServices.iWSRoboticsClient();                 
            //        //string sdr = tpams.GetTpamPassword("141.122.121.151", "ACTIVE-DIRECTORY_PRD", "BPBR-BRSAPA4174", "F:\\PRD\\TPAM\\id_dsa BPBR-BRSAPA4174", "RX732RO");
            //        //-------//

            //        TPAMWebServices.iWSRoboticsClient tpams = new TPAMWebServices.iWSRoboticsClient();

            //        string sdr = tpams.GetTpamPassword("141.122.121.152", "ACTIVE-DIRECTORY_PRD", "BPBR-BRSAPA4174", "F:\\PRD\\TPAM\\id_dsa BPBR-BRSAPA4174", "RX732RO");

            //        log.LogWrite("Extracted the password: " + sdr);

            //        string date = DateTime.Now.ToString("dd-mm-yyyy HH:mm tt");

            //        Login();

            //        if (login == true)
            //        {
            //            chrome.Navigate().GoToUrl("https://azased0013.nestle.com/?tid=1&fid=3");
            //            chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

            //            Thread.Sleep(30);
            //            changeBotPassword(sdr);

            //            Logout();
            //            //chrome.Close();
            //            //chrome.Quit();
            //        }
            //        else
            //        {
            //            chrome.Close();
            //            chrome.Quit();
            //        }

            //        log.LogWrite("End of the Execution.");

            //        //changeBotPassword(sdr);

            //        chrome.Quit();
            //    }
            //    catch (Exception ex)
            //    {
            //        if (ex.Message.Contains("The underlying connection was closed"))
            //        {
            //            log.LogWrite("TPAM Services are unavailable. Error Message: " + ex.Message);

            //            log.LogWrite("Mail sending starts.");

            //            string sBody = "Dear Kausar,\n\nThe TPAM Services are currently not available. Error Message:" + ex.Message + ". \n\nRegards\n" + "Kausar";
            //            MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
            //            SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

            //            client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

            //            try
            //            {
            //                client.Send(message);
            //                log.LogWrite("Mail is sent.");

            //            }
            //            catch (Exception ex1)
            //            {
            //                Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
            //                            ex1.ToString());
            //                log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

            //            }

            //        }
            //        else
            //        {
            //            log.LogWrite(ex.Message);
            //        }
            //        //throw;
            //    }

            //    //return;
            #endregion

            Environment.Exit(0);
        }

        public static void getPwd()
        {
            try
            {
                //logger.Debug("Started the TPAM Services.");
                log.LogWrite("Started the TPAM Services.");

                //Prod Services
                TPAMWebServices.iWSRoboticsClient tpams1 = new TPAMWebServices.iWSRoboticsClient();
                sdr1 = tpams1.GetTpamPassword("141.122.121.152", "ACTIVE-DIRECTORY_PRD", "BPBR-BRSAPA4174", "F:\\PRD\\TPAM\\id_dsa BPBR-BRSAPA4174", "RX732RO");
                log.LogWrite("Extracted the password for RX732RO : " + sdr1);

                TPAMWebServices.iWSRoboticsClient tpams2 = new TPAMWebServices.iWSRoboticsClient();
                sdr2 = tpams2.GetTpamPassword("141.122.121.152", "ACTIVE-DIRECTORY_PRD", "BPBR-BRSAPA4174", "F:\\PRD\\TPAM\\id_dsa BPBR-BRSAPA4174", "RX922RO");
                log.LogWrite("Extracted the password for RX922RO: " + sdr2);

                //PreProd Services
                TPAMWebServicePP.iWSRoboticsClient tpams_pp = new TPAMWebServicePP.iWSRoboticsClient();
                sdr3 = tpams_pp.GetTpamPassword("141.122.121.152", "ACTIVE-DIRECTORY_PRD", "BPBR-BRSAPA4172", "F:\\WSTpam\\KeyFile\\id_dsa BPBR-BRSAPA4172", "RX922PPRo");
                log.LogWrite("Extracted the password for RX922PPRo: " + sdr3);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("The underlying connection was closed"))
                {
                    log.LogWrite("TPAM Services are unavailable. Error Message: " + ex.Message);

                    log.LogWrite("Mail sending starts.");

                    string sBody = "Dear Kausar,\n\nThe TPAM Services are currently not available. Error Message:" + ex.Message + ". \n\nRegards\n" + "Kausar";
                    MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                    SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                    client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                    try
                    {
                        client.Send(message);
                        log.LogWrite("Mail is sent.");

                    }
                    catch (Exception ex1)
                    {
                        Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                    ex1.ToString());
                        log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                    }

                }
                else
                {
                    log.LogWrite(ex.Message);
                }
                //throw;
            }
        }

        public static void Login()
        {
            try
            {
                log.LogWrite("Logging In to Orchestrator.");

                //Login to portal
                ChromeOptions options = new ChromeOptions();

                options.AddAdditionalCapability("useAutomationExtension", false);

                //Get the application folder path
                string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                chrome = new ChromeDriver(path, options);
                //chrome = new ChromeDriver(options);

                chrome.Manage().Window.Maximize();
                chrome.Navigate().GoToUrl("https://azased0013.nestle.com"); //https://xsblra0002.nestle.com/account/login

                // Store the parent window of the driver
                String parentWindowHandle = chrome.CurrentWindowHandle;
                Console.WriteLine("Parent window's handle -> " + parentWindowHandle);

                chrome.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);

                IWebElement loginUserName = chrome.FindElement(By.CssSelector("input[data-cy = 'username']"));
                IWebElement loginPass = chrome.FindElement(By.CssSelector("input[data-cy = 'password']"));
                IWebElement loginBtn = chrome.FindElement(By.CssSelector("button[data-cy = 'login-btn']"));

                bool tbUNStatus = loginUserName.Enabled;
                bool tbPWDStatus = loginPass.Enabled;
                bool tbUNStatus_display = loginUserName.Displayed;
                bool tbPWDStatus_display = loginPass.Displayed;

                loginUserName.SendKeys("admin");
                loginPass.SendKeys("Nestle@1234");

                loginBtn.Click();
                log.LogWrite("LogIn Button clicked.");

                chrome.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

                IWebElement profileBtn = chrome.FindElement(By.CssSelector("button[data-cy='setting-menu-trigger']"));
                login = profileBtn.Displayed;

            }
            catch (Exception ex)
            {
                log.LogWrite(ex.Message);

                Console.WriteLine("Login Catch Error - " + ex.Message.ToString());
                throw;
            }
        }

        public static void changeBotPassword(string sdr)
        {
            string status = null;
            string type = null;

            try
            {
                log.LogWrite("Checking for the Robot ID.");

                chrome.Navigate().GoToUrl("https://azased0013.nestle.com/robots");

                ////bool isPresent = false;
                #region
                //IWebElement pageCount = chrome.FindElement(By.CssSelector("span[class='mat-paginator-range-label']"));  //span[class='pages-current-page']
                //string count = pageCount.Text.ToString();
                //string abc = count.Split('/')[1];
                //int currentPage = Convert.ToInt32(count.Split('/')[0]);
                //int totalPages = Convert.ToInt32(abc);


                //for (int i = currentPage; i <= totalPages; i++)
                //{
                //    //IWebElement nextPage = chrome.FindElement(By.CssSelector("button[uiclicktrack='Action: Grid: Next Page']"));
                //    IWebElement nextPage = chrome.FindElement(By.XPath("//button[@uiclicktrack='Action: Grid: Next Page']"));

                //    //string totalPages = count.Split("/".ToCharArray())[1].ToString();

                //    IList<IWebElement> botList = null;
                //    IWebElement botStatus = null;
                //    //IWebElement robot = null;

                //    botList = chrome.FindElements(By.CssSelector("tr[class='ui-grid-row ng-star-inserted']"));
                //    Actions action = new Actions(chrome);

                //    IWebElement Ordering = chrome.FindElement(By.CssSelector("th[data-title='Name']"));
                //    if (!Ordering.GetAttribute("aria-sort").Equals("ascending"))
                //    {
                //        Ordering.Click();
                //        logger.Info("Ascending Order clicked.");
                //    }
                //    else
                //    {
                //        try
                //        {
                //            logger.Info("Robots are in Ascending Order.");

                //            //robot = chrome.FindElement(By.XPath("//td[@title='RX732PPRo']"));

                //            botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div[@class='ng-star-inserted']"));
                //            status = botStatus.Text;

                //            IList<IWebElement> RowList = chrome.FindElements(By.CssSelector("tr[class='ui-grid-row ng-star-inserted']"));
                //            foreach (IWebElement item in RowList)
                //            {
                //                if (item.FindElements(By.CssSelector("td[class='ui-grid-cell grid-text-primary text-ellipsis ng-star-inserted']"))[0].Text.Equals("RX732RO"))
                //                {
                //                    type = item.FindElements(By.CssSelector("td[class='ui-grid-cell grid-text-primary text-ellipsis ng-star-inserted']"))[1].Text;
                //                    break;
                //                }
                //            }
                //            Console.WriteLine(type);

                //            logger.Info("Bot Type is " + type + " and Status is " + status);

                //            if (status != "Busy" && type != "Attended")
                //            {

                //                IWebElement editRobot = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@uiclicktrack='Action: Grid: Edit']"));
                //                action.MoveToElement(editRobot).Perform();

                //                editRobot.Click();
                //                logger.Info("Edit button clicked for the Robot.");

                //                IWebElement robotName = chrome.FindElement(By.CssSelector("input[data-cy='robot-name']"));
                //                IWebElement machine = chrome.FindElement(By.CssSelector("div[class='display-container text-ellipsis']"));
                //                IWebElement domainUser = chrome.FindElement(By.CssSelector("input[data-cy='robot-username']"));
                //                IWebElement paswrd = null;
                //                IWebElement updateButton = null;
                //                IWebElement cancelButton = null;

                //                Console.WriteLine(robotName.GetAttribute("value") + " - " + machine.Text + " - " + domainUser.GetAttribute("value"));

                //                if (robotName.GetAttribute("value") == "RX732RO" && machine.Text == "XS12-1BGA833" && domainUser.GetAttribute("value") == @"nestle\RX732RO")
                //                {
                //                    logger.Info("Robots data is validated.");

                //                    Console.WriteLine("You have selected on the right robot edit button");

                //                    //Writing the password in the Password Text box
                //                    paswrd = chrome.FindElement(By.CssSelector("input[data-cy='robot-password']"));
                //                    paswrd.Clear();
                //                    paswrd.SendKeys(sdr);

                //                    logger.Info("New Password is entered.");

                //                    //Clicking Update
                //                    updateButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-submit']"));
                //                    updateButton.Click();

                //                    logger.Info("New Password is updated.");

                //                    logger.Info("Mail sending starts.");

                //                    string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password is now updated with the latest one.\n\nRegards\n" + "Kausar";
                //                    MailMessage message = new MailMessage("Kausar.Pasha@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                //                    SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                //                    client.Credentials = new System.Net.NetworkCredential("xspashaka", "Nestle3411");

                //                    try
                //                    {
                //                        client.Send(message);
                //                        logger.Info("Mail is sent.");

                //                    }
                //                    catch (Exception ex1)
                //                    {
                //                        Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                //                                    ex1.ToString());
                //                        logger.Info("Mail Send exception : " + ex1.ToString() + ".");

                //                    }

                //                    ////Cancelling the Update
                //                    //cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                //                    //cancelButton.SendKeys(Keys.Escape);
                //                }
                //                else
                //                {
                //                    Console.WriteLine("You have not selected on the right robot edit button. Click on 'Cancel'");
                //                    cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                //                    cancelButton.Click();

                //                    logger.Info("Edit is cancelled.");

                //                }

                //                break;
                //            }
                //            else
                //            {
                //                logger.Info("Bot Type is " + type + " and Status is " + status + ".");

                //                logger.Info("Mail sending starts.");

                //                string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password was not reset.\n\nRegards\n" + "Kausar";
                //                MailMessage message = new MailMessage("Kausar.Pasha@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                //                SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                //                client.Credentials = new System.Net.NetworkCredential("xspashaka", "Nestle3411");

                //                try
                //                {
                //                    client.Send(message);
                //                    logger.Info("Mail is sent.");

                //                }
                //                catch (Exception ex1)
                //                {
                //                    Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                //                                ex1.ToString());
                //                    logger.Info("Mail Send exception : " + ex1.ToString() + ".");

                //                }
                //            }
                //        }
                //        catch (Exception ex)
                //        {
                //            log.LogWrite(ex.Message);

                //            nextPage.Click();

                //            logger.Info("Next Page is clicked.");
                //        }

                //    }
                //}
                #endregion

                IWebElement search = chrome.FindElement(By.Id("mat-input-0"));
                search.Click();
                search.SendKeys("RX732RO");
                //search.Submit();

                chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);

                try
                {
                    log.LogWrite("Robots are in Ascending Order.");

                    IWebElement botStatus = null;
                    //botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div[@class='ng-star-inserted']"));
                    //botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div/following-sibling::span[@class='ng-star-inserted']"));
                    botStatus = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[7]/div/span"));
                    //botStatus = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/mat-sidenav-container/mat-sidenav-content/div/div/div/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[7]/div/span"));
                    status = botStatus.Text;

                    log.LogWrite("Status is " + status);

                    chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(40);

                    //IList<IWebElement> RowList = chrome.FindElements(By.CssSelector("div[class='ui-grid-row ng-star-inserted']"));
                    //foreach (IWebElement item in RowList)
                    //{
                    //    type = item.FindElement(By.CssSelector("div[data-property='robot.type']")).Text;
                    //}

                    type = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[5]/div/span")).Text;
                    Console.WriteLine(type);
                    Actions action = new Actions(chrome);
                    log.LogWrite("Bot Type is " + type + " and Status is " + status);

                    //if (status != "Busy" && type != "Attended")
                    //{
                    ////New Addition
                    //IWebElement btnMore = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/mat-sidenav-container/mat-sidenav-content/div/div/div/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[9]/div/button"));
                    IWebElement btnMore = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[10]/div/button"));
                    //IWebElement btnMore = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@data-cy='grid-action-menu']"));
                    btnMore.Click();

                    //IWebElement editRobot = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@uiclicktrack='Action: Grid: Edit']"));
                    //IWebElement editRobot = chrome.FindElement(By.XPath("//*[@id='mat-menu-panel-5']/div/button[1]"));
                    IWebElement editRobot = chrome.FindElement(By.XPath("//*[@id='mat-menu-panel-11']/div/button[1]"));
                    action.MoveToElement(editRobot).Perform();

                    editRobot.Click();
                    log.LogWrite("Edit button clicked for the Robot.");

                    IWebElement robotName = chrome.FindElement(By.CssSelector("input[data-cy='robot-name']"));
                    //IWebElement machine = chrome.FindElement(By.CssSelector("div[class='display-container text-ellipsis']"));
                    //IWebElement machine = chrome.FindElement(By.CssSelector("input[data-cy='robot-machine']"));
                    IWebElement domainUser = chrome.FindElement(By.CssSelector("input[data-cy='robot-username']"));
                    IWebElement paswrd = null;
                    IWebElement updateButton = null;
                    IWebElement cancelButton = null;

                    //Console.WriteLine(robotName.GetAttribute("value") + " - " + machine.Text + " - " + domainUser.GetAttribute("value"));
                    Console.WriteLine(robotName.GetAttribute("value") + " - " + domainUser.GetAttribute("value"));

                    if (robotName.GetAttribute("value") == "RX732RO" && domainUser.GetAttribute("value") == @"nestle\rx732ro") //machine.Text == "XS12-1BGA833" &&
                    {
                        log.LogWrite("Robots data is validated.");

                        Console.WriteLine("You have selected on the right robot edit button");

                        //Writing the password in the Password Text box
                        paswrd = chrome.FindElement(By.CssSelector("input[data-cy='robot-password']"));
                        paswrd.Clear();
                        paswrd.SendKeys(sdr);

                        log.LogWrite("New Password is entered.");

                        //Clicking Update
                        updateButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-submit']"));
                        updateButton.Click();

                        log.LogWrite("New Password is updated.");

                        log.LogWrite("Mail sending starts.");

                        string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password is now updated with the latest one.\n\nRegards\n" + "Kausar";
                        MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                        SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                        client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                        try
                        {
                            client.Send(message);
                            log.LogWrite("Mail is sent.");

                        }
                        catch (Exception ex1)
                        {
                            Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                        ex1.ToString());
                            log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                        }

                        ////Cancelling the Update
                        //cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                        //cancelButton.SendKeys(Keys.Escape);
                    }
                    else
                    {
                        Console.WriteLine("You have not selected on the right robot edit button. Click on 'Cancel'");
                        cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                        cancelButton.Click();

                        log.LogWrite("Edit is cancelled.");

                    }

                    //}
                    //else
                    //{
                    //    log.LogWrite("Bot Type is " + type + " and Status is " + status + ".");

                    //    log.LogWrite("Mail sending starts.");

                    //    string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password was not reset.\n\nRegards\n" + "Kausar";
                    //    MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                    //    SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                    //    client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                    //    try
                    //    {
                    //        client.Send(message);
                    //        log.LogWrite("Mail is sent.");

                    //    }
                    //    catch (Exception ex1)
                    //    {
                    //        Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                    //                    ex1.ToString());
                    //        log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                    //    }
                    //}
                }
                catch (Exception ex)
                {
                    log.LogWrite("Change bot Password-TRY-Catch2-Error : " + ex.Message);

                }


            }
            catch (Exception ex)
            {
                log.LogWrite(ex.Message);

                Console.WriteLine("Change Bot Pwd Error - " + ex.Message.ToString());

                log.LogWrite("Mail sending starts.");

                string sBody = "Dear Kausar,\n\nThe password was not reset due to the error: " + ex.Message + ".\n\nRegards\n" + "Kausar";
                MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                try
                {
                    client.Send(message);
                    log.LogWrite("Mail is sent.");

                }
                catch (Exception ex1)
                {
                    Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                ex1.ToString());
                    log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                }

                //throw;
            }
        }

        public static void changeMultipleBotPassword(string bot, string sdr)
        {
            string status = null;
            string type = null;

            try
            {
                log.LogWrite("Checking for the Robot ID.");

                chrome.Navigate().GoToUrl("https://azased0013.nestle.com/robots");                

                IWebElement search = chrome.FindElement(By.Id("mat-input-0"));
                search.Click();
                search.SendKeys(bot);
                //search.Submit();
                Thread.Sleep(30);
                chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
                
                try
                {
                    log.LogWrite("Robots are in Ascending Order.");

                    IWebElement botStatus = null;
                    //botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div[@class='ng-star-inserted']"));
                    //botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div/following-sibling::span[@class='ng-star-inserted']"));
                    botStatus = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[7]/div/span"));
                    //botStatus = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/mat-sidenav-container/mat-sidenav-content/div/div/div/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[7]/div/span"));
                    status = botStatus.Text;

                    log.LogWrite("Status is " + status);
                    Thread.Sleep(30);
                    chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(40);

                    //IList<IWebElement> RowList = chrome.FindElements(By.CssSelector("div[class='ui-grid-row ng-star-inserted']"));
                    //foreach (IWebElement item in RowList)
                    //{
                    //    type = item.FindElement(By.CssSelector("div[data-property='robot.type']")).Text;
                    //}

                    type = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[5]/div/span")).Text;
                    Console.WriteLine(type);
                    Actions action = new Actions(chrome);
                    log.LogWrite("Bot Type is " + type + " and Status is " + status);

                    //if (status != "Busy" && type != "Attended")
                    //{
                    ////New Addition
                    //IWebElement btnMore = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/mat-sidenav-container/mat-sidenav-content/div/div/div/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[9]/div/button"));
                    IWebElement btnMore = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[10]/div/button"));
                    //IWebElement btnMore = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@data-cy='grid-action-menu']"));
                    btnMore.Click();

                    //IWebElement editRobot = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@uiclicktrack='Action: Grid: Edit']"));
                    //IWebElement editRobot = chrome.FindElement(By.XPath("//*[@id='mat-menu-panel-5']/div/button[1]"));
                    IWebElement editRobot = chrome.FindElement(By.XPath("//*[@id='mat-menu-panel-11']/div/button[1]"));
                    action.MoveToElement(editRobot).Perform();

                    editRobot.Click();
                    log.LogWrite("Edit button clicked for the Robot.");

                    IWebElement robotName = chrome.FindElement(By.CssSelector("input[data-cy='robot-name']"));
                    //IWebElement machine = chrome.FindElement(By.CssSelector("div[class='display-container text-ellipsis']"));
                    //IWebElement machine = chrome.FindElement(By.CssSelector("input[data-cy='robot-machine']"));
                    IWebElement domainUser = chrome.FindElement(By.CssSelector("input[data-cy='robot-username']"));
                    IWebElement paswrd = null;
                    IWebElement updateButton = null;
                    IWebElement cancelButton = null;

                    //Console.WriteLine(robotName.GetAttribute("value") + " - " + machine.Text + " - " + domainUser.GetAttribute("value"));
                    Console.WriteLine(robotName.GetAttribute("value") + " - " + domainUser.GetAttribute("value"));
                    log.LogWrite(robotName.GetAttribute("value") + " - " + domainUser.GetAttribute("value"));

                    if (robotName.GetAttribute("value") == bot && domainUser.GetAttribute("value") == @"nestle\"+bot.ToLower()) //machine.Text == "XS12-1BGA833" &&
                    {
                        log.LogWrite("Robots data is validated.");

                        Console.WriteLine("You have selected on the right robot edit button");

                        //Writing the password in the Password Text box
                        paswrd = chrome.FindElement(By.CssSelector("input[data-cy='robot-password']"));
                        paswrd.Clear();
                        paswrd.SendKeys(sdr);

                        log.LogWrite("New Password is entered.");

                        //Clicking Update
                        updateButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-submit']"));
                        updateButton.Click();

                        log.LogWrite("New Password is updated.");

                        log.LogWrite("Mail sending starts.");

                        string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password is now updated with the latest one.\n\nRegards\n" + "Kausar";
                        MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                        SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                        client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                        try
                        {
                            client.Send(message);
                            log.LogWrite("Mail is sent.");

                        }
                        catch (Exception ex1)
                        {
                            Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                        ex1.ToString());
                            log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                        }

                        ////Cancelling the Update
                        //cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                        //cancelButton.SendKeys(Keys.Escape);
                    }
                    else
                    {
                        Console.WriteLine("You have not selected on the right robot edit button. Click on 'Cancel'");
                        cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                        cancelButton.Click();

                        log.LogWrite("Edit is cancelled.");

                    }

                    //}
                    //else
                    //{
                    //    log.LogWrite("Bot Type is " + type + " and Status is " + status + ".");

                    //    log.LogWrite("Mail sending starts.");

                    //    string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password was not reset.\n\nRegards\n" + "Kausar";
                    //    MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                    //    SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                    //    client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                    //    try
                    //    {
                    //        client.Send(message);
                    //        log.LogWrite("Mail is sent.");

                    //    }
                    //    catch (Exception ex1)
                    //    {
                    //        Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                    //                    ex1.ToString());
                    //        log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                    //    }
                    //}
                }
                catch (Exception ex)
                {
                    log.LogWrite("Change bot Password-TRY-Catch2-Error : " + ex.Message);

                }


            }
            catch (Exception ex)
            {
                log.LogWrite(ex.Message);

                Console.WriteLine("Change Bot Pwd Error - " + ex.Message.ToString());

                log.LogWrite("Mail sending starts.");

                string sBody = "Dear Kausar,\n\nThe password was not reset due to the error: " + ex.Message + ".\n\nRegards\n" + "Kausar";
                MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                try
                {
                    client.Send(message);
                    log.LogWrite("Mail is sent.");

                }
                catch (Exception ex1)
                {
                    Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                ex1.ToString());
                    log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                }

                //throw;
            }
        }

        public static void changeBotPassword()
        {
            string status = null;
            string type = null;

            try
            {
                log.LogWrite("Checking for the Robot ID.");

                chrome.Navigate().GoToUrl("https://azased0013.nestle.com/robots");

                IWebElement search = chrome.FindElement(By.Id("mat-input-0"));
                search.Click();
                search.SendKeys("RX732RO");
                //search.Submit();

                chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);

                try
                {
                    log.LogWrite("Robots are in Ascending Order.");

                    IWebElement botStatus = null;
                    //botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div[@class='ng-star-inserted']"));
                    //botStatus = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//div/following-sibling::span[@class='ng-star-inserted']"));
                    botStatus = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[7]/div/span"));
                    //botStatus = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/mat-sidenav-container/mat-sidenav-content/div/div/div/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[7]/div/span"));
                    status = botStatus.Text;

                    log.LogWrite("Status is " + status);

                    chrome.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(40);

                    //IList<IWebElement> RowList = chrome.FindElements(By.CssSelector("div[class='ui-grid-row ng-star-inserted']"));
                    //foreach (IWebElement item in RowList)
                    //{
                    //    type = item.FindElement(By.CssSelector("div[data-property='robot.type']")).Text;
                    //}

                    type = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[5]/div/span")).Text;
                    Console.WriteLine(type);
                    Actions action = new Actions(chrome);
                    log.LogWrite("Bot Type is " + type + " and Status is " + status);

                    //if (status != "Busy" && type != "Attended")
                    //{
                    ////New Addition
                    //IWebElement btnMore = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/mat-sidenav-container/mat-sidenav-content/div/div/div/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[9]/div/button"));
                    IWebElement btnMore = chrome.FindElement(By.XPath("/html/body/ui-app/ng-component/ui-sidenav/mat-sidenav-container/mat-sidenav-content/div/ui-menu-navigation/section/section/ng-component/ui-grid/div[2]/div[1]/div[2]/div[2]/div[10]/div/button"));
                    //IWebElement btnMore = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@data-cy='grid-action-menu']"));
                    btnMore.Click();

                    //IWebElement editRobot = chrome.FindElement(By.XPath("//td[@title='RX732RO']/following-sibling::td//button[@uiclicktrack='Action: Grid: Edit']"));
                    //IWebElement editRobot = chrome.FindElement(By.XPath("//*[@id='mat-menu-panel-5']/div/button[1]"));
                    IWebElement editRobot = chrome.FindElement(By.XPath("//*[@id='mat-menu-panel-11']/div/button[1]"));
                    action.MoveToElement(editRobot).Perform();

                    editRobot.Click();
                    log.LogWrite("Edit button clicked for the Robot.");

                    IWebElement robotName = chrome.FindElement(By.CssSelector("input[data-cy='robot-name']"));
                    //IWebElement machine = chrome.FindElement(By.CssSelector("div[class='display-container text-ellipsis']"));
                    //IWebElement machine = chrome.FindElement(By.CssSelector("input[data-cy='robot-machine']"));
                    IWebElement domainUser = chrome.FindElement(By.CssSelector("input[data-cy='robot-username']"));
                    IWebElement paswrd = null;
                    IWebElement updateButton = null;
                    IWebElement cancelButton = null;

                    //Console.WriteLine(robotName.GetAttribute("value") + " - " + machine.Text + " - " + domainUser.GetAttribute("value"));
                    Console.WriteLine(robotName.GetAttribute("value") + " - " + domainUser.GetAttribute("value"));

                    if (robotName.GetAttribute("value") == "RX732RO" && domainUser.GetAttribute("value") == @"nestle\rx732ro") //machine.Text == "XS12-1BGA833" &&
                    {
                        log.LogWrite("Robots data is validated.");

                        Console.WriteLine("You have selected on the right robot edit button");

                        //Writing the password in the Password Text box
                        paswrd = chrome.FindElement(By.CssSelector("input[data-cy='robot-password']"));
                        paswrd.Clear();
                        //paswrd.SendKeys(sdr);

                        log.LogWrite("New Password is entered.");

                        //Clicking Update
                        updateButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-submit']"));
                        updateButton.Click();

                        log.LogWrite("New Password is updated.");

                        log.LogWrite("Mail sending starts.");

                        string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password is now updated with the latest one.\n\nRegards\n" + "Kausar";
                        MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                        SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                        client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                        try
                        {
                            client.Send(message);
                            log.LogWrite("Mail is sent.");

                        }
                        catch (Exception ex1)
                        {
                            Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                        ex1.ToString());
                            log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                        }

                        ////Cancelling the Update
                        //cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                        //cancelButton.SendKeys(Keys.Escape);
                    }
                    else
                    {
                        Console.WriteLine("You have not selected on the right robot edit button. Click on 'Cancel'");
                        cancelButton = chrome.FindElement(By.CssSelector("button[data-cy='robot-cancel']"));
                        cancelButton.Click();

                        log.LogWrite("Edit is cancelled.");

                    }

                    //}
                    //else
                    //{
                    //    log.LogWrite("Bot Type is " + type + " and Status is " + status + ".");

                    //    log.LogWrite("Mail sending starts.");

                    //    string sBody = "Dear Kausar,\n\nBot Type is " + type + " and Status is " + status + ".\n\nThe password was not reset.\n\nRegards\n" + "Kausar";
                    //    MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                    //    SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                    //    client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                    //    try
                    //    {
                    //        client.Send(message);
                    //        log.LogWrite("Mail is sent.");

                    //    }
                    //    catch (Exception ex1)
                    //    {
                    //        Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                    //                    ex1.ToString());
                    //        log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                    //    }
                    //}
                }
                catch (Exception ex)
                {
                    log.LogWrite("Change bot Password-TRY-Catch2-Error : " + ex.Message);

                }


            }
            catch (Exception ex)
            {
                log.LogWrite(ex.Message);

                Console.WriteLine("Change Bot Pwd Error - " + ex.Message.ToString());

                log.LogWrite("Mail sending starts.");

                string sBody = "Dear Kausar,\n\nThe password was not reset due to the error: " + ex.Message + ".\n\nRegards\n" + "Kausar";
                MailMessage message = new MailMessage("Subham.Das@XS.nestle.com", "Kausar.Pasha@XS.nestle.com", "Status of Updating Orchestrator bot Password from TPAM", sBody);
                SmtpClient client = new SmtpClient("Smtp.eur.nestle.com", 587);

                client.Credentials = new System.Net.NetworkCredential("xsdassu3", "Subh@270693@21");

                try
                {
                    client.Send(message);
                    log.LogWrite("Mail is sent.");

                }
                catch (Exception ex1)
                {
                    Console.WriteLine("Exception caught in CreateTestMessage1(): {0}",
                                ex1.ToString());
                    log.LogWrite("Mail Send exception : " + ex1.ToString() + ".");

                }

                //throw;
            }
        }

        public static void Logout()
        {
            try
            {
                log.LogWrite("Proceeding to logout.");

                IWebElement profileBtn = chrome.FindElement(By.CssSelector("button[data-cy='setting-menu-trigger']"));
                profileBtn.Click();

                IWebElement logoutBtn = chrome.FindElement(By.CssSelector("a[data-cy='logout-btn']"));
                logoutBtn.Click();

                log.LogWrite("Orchestrator is logged out successfully.");

                chrome.Close();
                chrome.Quit();
            }
            catch (Exception ex)
            {
                log.LogWrite(ex.Message);

                Console.WriteLine("Logout Error - " + ex.Message.ToString());
                throw;
            }
        }
    }
}
